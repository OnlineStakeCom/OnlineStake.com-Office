const wallets = {
    btc: '1EHqQBfc4gTmE9PpNds4Y2i65ndKJoSwNW',
    eth: '0x5eb2e081483a0bf143692801fe12346544c40370',
    ltc: 'LT6nKxsAAwv1o4RPkUqpQXZRux67JEYRpf',
    doge: 'DRuq3EX75rygK29zhoW3atq6epdDKG3oiF',
    bch: '1EHqQBfc4gTmE9PpNds4Y2i65ndKJoSwNW',
    trx: 'TKbKHbXBb8cKqZdscU9cu5PtCf87BMBVMV'
}