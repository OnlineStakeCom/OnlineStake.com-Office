const dictionary = {
    test: 'working',
    testing: 'working',
}